<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="#">add_post</a>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <h1><?php echo e($data->titile_m); ?></h1>
     <h3><?php echo e($data->m_par); ?></h3>
     <h3><?php echo e($data->like); ?></h3>
     <a href="#">edit</a>
     <a href="#">delete</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</body>
</html><?php /**PATH C:\Users\almas\Desktop\weblog\web2\weblog\resources\views/admin.blade.php ENDPATH**/ ?>